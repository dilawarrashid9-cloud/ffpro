# FF Pro Panel

A standalone aim and reflex **training app** for Android, built with Kotlin and Jetpack Compose in a black and neon-green esports theme.

> FF Pro Panel is an independent practice tool. It is **not** affiliated with Garena or Free Fire, and it **never** injects into, modifies, reads from, automates, or interacts with any game or anti-cheat system. It runs entirely on its own screens and stores everything locally on your device.

## Features

| Area | What it does |
|---|---|
| Dashboard | Active profile card, sessions / best score / accuracy / streak tiles, mode shortcuts with personal bests, haptics toggle and round length (15 / 30 / 60 s). |
| Headshot Aim Trainer | Human-silhouette targets with a shrinking timer ring. Head = 100, body = 30, miss = -10. Easy / Normal / Hard. |
| Reflex Drill | 5 rounds: wait for the screen to flash green, then tap. False starts are tracked and penalised. |
| Moving Target Practice | Strafing targets that change direction and speed up during the round. Easy / Normal / Hard. |
| Crosshair Designer | 5 shapes, arm length, thickness, gap, opacity, outline, colour swatches and hue slider, quick styles, and preview on dark / grass / sand / sky / white backgrounds with sample targets. |
| Sensitivity Presets | Six note-keeping sliders (general, red dot, 2x, 4x, sniper, free look). Built-in and custom presets. |
| HUD Presets | Live phone-layout preview with 2 / 3 / 4-finger layouts, fire button size and opacity, joystick size, HUD scale. Built-in and custom presets. |
| Saved Profiles | Bundle crosshair + sensitivity + HUD under a name. Apply, update from current setup, delete. |
| Statistics | Per-mode filter, totals, accuracy, reaction times, last-12-scores bar chart, personal bests, 30-entry history, clear history. |

Persistence: `SharedPreferences` + JSON (`org.json`). No network permission, no accounts, no analytics.

## Project structure

```
FFProPanel/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/ (values, adaptive launcher icon)
        └── java/com/ffpro/panel/
            ├── MainActivity.kt          # navigation + bottom bar
            ├── AppViewModel.kt          # state + persistence calls
            ├── data/ Models.kt, Storage.kt, Stats.kt
            └── ui/
                ├── Components.kt, Drawing.kt
                ├── theme/Theme.kt
                └── screens/
                    ├── DashboardScreen.kt
                    ├── AimTrainerScreen.kt
                    ├── ReflexDrillScreen.kt
                    ├── MovingTargetScreen.kt
                    ├── CrosshairScreen.kt
                    ├── PresetsScreen.kt
                    ├── ProfilesScreen.kt
                    ├── StatsScreen.kt
                    └── TrainerCommon.kt
```

## Build the APK in Android Studio

**Requirements:** Android Studio Koala (2024.1) or newer, an internet connection for the first Gradle sync, Android SDK Platform 34 (Studio offers to install it). The JDK 17 bundled with Android Studio is used automatically.

1. Unzip the project and choose **File > Open**, then select the `FFProPanel` folder.
2. Wait for **Gradle sync** to finish. Studio downloads Gradle 8.7 and the dependencies. If it asks to install SDK Platform 34 or build tools, accept.
3. Build a debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. When the notification appears, click **locate**. The file is at:
   `app/build/outputs/apk/debug/app-debug.apk`
5. Install it:
   - **USB:** enable *Developer options > USB debugging* on the phone, connect it, and press the green **Run** button in Studio; or run `adb install -r app-debug.apk`.
   - **Manual:** copy `app-debug.apk` to the phone, open it from a file manager, and allow "Install unknown apps" for that file manager when prompted.

### Optional: release APK

1. **Build > Generate Signed Bundle / APK > APK**.
2. Create a new keystore (keep it and its passwords safe), choose the **release** variant, and finish.
3. The signed APK is written to `app/release/`.

### Optional: command line

The project ships `gradle-wrapper.properties` only (no binary jar). Generate the wrapper once with a local Gradle install, then build:

```
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```

## Troubleshooting

- **"SDK location not found":** open **File > Project Structure > SDK Location**, or let Studio create `local.properties` automatically.
- **Sync fails offline:** the first sync needs internet access to Google's Maven repository and Maven Central.
- **JDK errors:** in **Settings > Build, Execution, Deployment > Build Tools > Gradle**, set *Gradle JDK* to the bundled JDK 17.
- **App is blocked on install:** allow installing from your file manager, or install over USB with `adb`.

## Notes

- Sensitivity and HUD values are personal notes. The app has no connection to any game, so applying a preset here does not change any in-game setting; copy the numbers manually if you want to use them.
- Training scores are only comparable within the same mode, difficulty and round length.
