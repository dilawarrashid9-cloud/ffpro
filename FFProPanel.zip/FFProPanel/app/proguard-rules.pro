# FF Pro Panel - no special rules needed (minification is disabled by default).
