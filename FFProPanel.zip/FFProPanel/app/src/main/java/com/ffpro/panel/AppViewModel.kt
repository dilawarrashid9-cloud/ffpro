package com.ffpro.panel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.ffpro.panel.data.AppSettings
import com.ffpro.panel.data.CrosshairConfig
import com.ffpro.panel.data.HudConfig
import com.ffpro.panel.data.HudPreset
import com.ffpro.panel.data.Profile
import com.ffpro.panel.data.SensitivityConfig
import com.ffpro.panel.data.SensitivityPreset
import com.ffpro.panel.data.SessionRecord
import com.ffpro.panel.data.Storage
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.newId

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = Storage(app)

    var crosshair by mutableStateOf(storage.loadCrosshair())
        private set
    var sensitivity by mutableStateOf(storage.loadSensitivity())
        private set
    var hud by mutableStateOf(storage.loadHud())
        private set
    var sensPresets by mutableStateOf(storage.loadSensPresets())
        private set
    var hudPresets by mutableStateOf(storage.loadHudPresets())
        private set
    var profiles by mutableStateOf(storage.loadProfiles())
        private set
    var activeProfileId by mutableStateOf(storage.loadActiveProfileId())
        private set
    var sessions by mutableStateOf(storage.loadSessions())
        private set
    var settings by mutableStateOf(storage.loadSettings())
        private set

    // ---- current setup ----

    fun updateCrosshair(c: CrosshairConfig) {
        crosshair = c
        storage.saveCrosshair(c)
    }

    fun updateSensitivity(s: SensitivityConfig) {
        sensitivity = s
        storage.saveSensitivity(s)
    }

    fun updateHud(h: HudConfig) {
        hud = h
        storage.saveHud(h)
    }

    // ---- presets ----

    fun saveSensPreset(name: String) {
        sensPresets = sensPresets + SensitivityPreset(newId(), name, sensitivity)
        storage.saveSensPresets(sensPresets)
    }

    fun deleteSensPreset(id: String) {
        sensPresets = sensPresets.filterNot { it.id == id && !it.builtIn }
        storage.saveSensPresets(sensPresets)
    }

    fun loadSensPreset(p: SensitivityPreset) = updateSensitivity(p.config)

    fun saveHudPreset(name: String) {
        hudPresets = hudPresets + HudPreset(newId(), name, hud)
        storage.saveHudPresets(hudPresets)
    }

    fun deleteHudPreset(id: String) {
        hudPresets = hudPresets.filterNot { it.id == id && !it.builtIn }
        storage.saveHudPresets(hudPresets)
    }

    fun loadHudPreset(p: HudPreset) = updateHud(p.config)

    // ---- profiles ----

    fun saveProfile(name: String) {
        val p = Profile(newId(), name, crosshair, sensitivity, hud, System.currentTimeMillis())
        profiles = profiles + p
        activeProfileId = p.id
        storage.saveProfiles(profiles)
        storage.saveActiveProfileId(p.id)
    }

    fun updateProfileFromCurrent(id: String) {
        profiles = profiles.map {
            if (it.id == id) it.copy(crosshair = crosshair, sensitivity = sensitivity, hud = hud) else it
        }
        storage.saveProfiles(profiles)
    }

    fun applyProfile(id: String) {
        val p = profiles.firstOrNull { it.id == id } ?: return
        updateCrosshair(p.crosshair)
        updateSensitivity(p.sensitivity)
        updateHud(p.hud)
        activeProfileId = id
        storage.saveActiveProfileId(id)
    }

    fun deleteProfile(id: String) {
        profiles = profiles.filterNot { it.id == id }
        storage.saveProfiles(profiles)
        if (activeProfileId == id) {
            activeProfileId = null
            storage.saveActiveProfileId(null)
        }
    }

    // ---- sessions ----

    fun recordSession(r: SessionRecord) {
        sessions = (sessions + r).takeLast(500)
        storage.saveSessions(sessions)
    }

    fun clearSessions() {
        sessions = emptyList()
        storage.saveSessions(sessions)
    }

    fun bestScore(mode: TrainingMode): Int =
        sessions.filter { it.mode == mode }.maxOfOrNull { it.score } ?: 0

    // ---- settings ----

    fun updateSettings(s: AppSettings) {
        settings = s
        storage.saveSettings(s)
    }
}
