package com.ffpro.panel

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ffpro.panel.ui.screens.AimTrainerScreen
import com.ffpro.panel.ui.screens.CrosshairScreen
import com.ffpro.panel.ui.screens.DashboardScreen
import com.ffpro.panel.ui.screens.MovingTargetScreen
import com.ffpro.panel.ui.screens.PresetsScreen
import com.ffpro.panel.ui.screens.ProfilesScreen
import com.ffpro.panel.ui.screens.ReflexDrillScreen
import com.ffpro.panel.ui.screens.StatsScreen
import com.ffpro.panel.ui.theme.FF
import com.ffpro.panel.ui.theme.FFTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            FFTheme {
                FFApp()
            }
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("crosshair", "Crosshair", Icons.Filled.Place),
    Tab("presets", "Presets", Icons.Filled.Build),
    Tab("profiles", "Profiles", Icons.Filled.Person),
    Tab("stats", "Stats", Icons.Filled.Star)
)

@Composable
fun FFApp(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = TABS.any { it.route == route }

    fun go(dest: String) {
        nav.navigate(dest) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = FF.Black,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = FF.Surface) {
                    TABS.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { go(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = FF.Black,
                                selectedTextColor = FF.Neon,
                                indicatorColor = FF.Neon,
                                unselectedIconColor = FF.Muted,
                                unselectedTextColor = FF.Muted
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { DashboardScreen(vm, go = { go(it) }) }
            composable("crosshair") { CrosshairScreen(vm) }
            composable("presets") { PresetsScreen(vm) }
            composable("profiles") { ProfilesScreen(vm) }
            composable("stats") { StatsScreen(vm) }
            composable("aim") { AimTrainerScreen(vm, onBack = { nav.popBackStack() }) }
            composable("reflex") { ReflexDrillScreen(vm, onBack = { nav.popBackStack() }) }
            composable("moving") { MovingTargetScreen(vm, onBack = { nav.popBackStack() }) }
        }
    }
}
