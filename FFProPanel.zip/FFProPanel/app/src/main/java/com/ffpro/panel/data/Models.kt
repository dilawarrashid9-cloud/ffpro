package com.ffpro.panel.data

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

enum class CrosshairStyle(val label: String) {
    CROSS("Cross"),
    CROSS_DOT("Cross + Dot"),
    DOT("Dot"),
    CIRCLE("Circle"),
    T_SHAPE("T-Shape")
}

data class CrosshairConfig(
    val style: CrosshairStyle = CrosshairStyle.CROSS_DOT,
    val color: Int = 0xFF39FF14.toInt(),
    val size: Float = 18f,
    val thickness: Float = 2f,
    val gap: Float = 5f,
    val opacity: Float = 1f,
    val outline: Boolean = true
)

data class SensitivityConfig(
    val general: Int = 70,
    val redDot: Int = 65,
    val scope2x: Int = 60,
    val scope4x: Int = 55,
    val sniper: Int = 40,
    val freeLook: Int = 50
)

data class HudConfig(
    val fingers: Int = 3,
    val fireSize: Int = 70,
    val fireOpacity: Int = 80,
    val joystickSize: Int = 60,
    val hudScale: Int = 100
)

data class SensitivityPreset(
    val id: String,
    val name: String,
    val config: SensitivityConfig,
    val builtIn: Boolean = false
)

data class HudPreset(
    val id: String,
    val name: String,
    val config: HudConfig,
    val builtIn: Boolean = false
)

data class Profile(
    val id: String,
    val name: String,
    val crosshair: CrosshairConfig,
    val sensitivity: SensitivityConfig,
    val hud: HudConfig,
    val createdAt: Long
)

enum class TrainingMode(val label: String) {
    AIM("Headshot Aim"),
    REFLEX("Reflex Drill"),
    MOVING("Moving Target")
}

enum class Difficulty(
    val label: String,
    val sizeMul: Float,
    val lifetimeMs: Long,
    val speedMul: Float,
    val targetCount: Int
) {
    EASY("Easy", 1.3f, 2200L, 0.7f, 1),
    NORMAL("Normal", 1.0f, 1600L, 1.0f, 2),
    HARD("Hard", 0.75f, 1100L, 1.35f, 2)
}

data class SessionRecord(
    val id: String,
    val mode: TrainingMode,
    val difficulty: String,
    val timestamp: Long,
    val score: Int,
    val hits: Int,
    val headshots: Int,
    val misses: Int,
    val avgReactionMs: Int,
    val bestReactionMs: Int,
    val durationSec: Int
) {
    val accuracy: Float
        get() = if (hits + misses == 0) 0f else hits.toFloat() / (hits + misses)
}

data class AppSettings(
    val haptics: Boolean = true,
    val durationSec: Int = 30
)

object Defaults {
    val sensitivityPresets = listOf(
        SensitivityPreset("builtin_balanced", "Balanced", SensitivityConfig(70, 65, 60, 55, 40, 50), true),
        SensitivityPreset("builtin_flick", "Fast Flick", SensitivityConfig(90, 85, 75, 70, 55, 60), true),
        SensitivityPreset("builtin_precision", "Precision", SensitivityConfig(50, 45, 40, 35, 25, 40), true)
    )

    val hudPresets = listOf(
        HudPreset("builtin_2f", "2-Finger Classic", HudConfig(2, 60, 80, 55, 100), true),
        HudPreset("builtin_3f", "3-Finger Claw", HudConfig(3, 70, 80, 60, 100), true),
        HudPreset("builtin_4f", "4-Finger Pro", HudConfig(4, 75, 75, 60, 95), true)
    )
}
