package com.ffpro.panel.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

data class StatsSummary(
    val sessions: Int,
    val bestScore: Int,
    val avgAccuracy: Float,
    val totalSeconds: Int,
    val avgReactionMs: Int,
    val bestReactionMs: Int
)

fun summarize(list: List<SessionRecord>): StatsSummary {
    if (list.isEmpty()) return StatsSummary(0, 0, 0f, 0, 0, 0)
    val withAvg = list.filter { it.avgReactionMs > 0 }
    val withBest = list.filter { it.bestReactionMs > 0 }
    return StatsSummary(
        sessions = list.size,
        bestScore = list.maxOf { it.score },
        avgAccuracy = list.map { it.accuracy }.average().toFloat(),
        totalSeconds = list.sumOf { it.durationSec },
        avgReactionMs = if (withAvg.isEmpty()) 0 else withAvg.map { it.avgReactionMs }.average().roundToInt(),
        bestReactionMs = withBest.minOfOrNull { it.bestReactionMs } ?: 0
    )
}

/** Consecutive days (ending today or yesterday) with at least one session. */
fun streakDays(list: List<SessionRecord>): Int {
    if (list.isEmpty()) return 0
    val zone = ZoneId.systemDefault()
    val days = list.map { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() }.toSet()
    var d = LocalDate.now(zone)
    if (d !in days) d = d.minusDays(1)
    var n = 0
    while (d in days) {
        n++
        d = d.minusDays(1)
    }
    return n
}
