package com.ffpro.panel.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local persistence using SharedPreferences + JSON (org.json is part of Android).
 * Nothing leaves the device.
 */
class Storage(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("ff_pro_panel", Context.MODE_PRIVATE)

    // ---- current setup ----

    fun loadCrosshair(): CrosshairConfig =
        decode(K_CROSSHAIR, ::crosshairFrom) ?: CrosshairConfig()

    fun saveCrosshair(c: CrosshairConfig) = putJson(K_CROSSHAIR, crosshairToJson(c))

    fun loadSensitivity(): SensitivityConfig =
        decode(K_SENS, ::sensFrom) ?: SensitivityConfig()

    fun saveSensitivity(s: SensitivityConfig) = putJson(K_SENS, sensToJson(s))

    fun loadHud(): HudConfig = decode(K_HUD, ::hudFrom) ?: HudConfig()

    fun saveHud(h: HudConfig) = putJson(K_HUD, hudToJson(h))

    // ---- presets (only custom ones are stored) ----

    fun loadSensPresets(): List<SensitivityPreset> {
        val custom = decodeList(K_SENS_PRESETS) { o ->
            SensitivityPreset(
                id = o.getString("id"),
                name = o.getString("name"),
                config = sensFrom(o.getJSONObject("config"))
            )
        }
        return Defaults.sensitivityPresets + custom
    }

    fun saveSensPresets(list: List<SensitivityPreset>) {
        val arr = JSONArray()
        list.filter { !it.builtIn }.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("config", sensToJson(it.config))
            )
        }
        prefs.edit().putString(K_SENS_PRESETS, arr.toString()).apply()
    }

    fun loadHudPresets(): List<HudPreset> {
        val custom = decodeList(K_HUD_PRESETS) { o ->
            HudPreset(
                id = o.getString("id"),
                name = o.getString("name"),
                config = hudFrom(o.getJSONObject("config"))
            )
        }
        return Defaults.hudPresets + custom
    }

    fun saveHudPresets(list: List<HudPreset>) {
        val arr = JSONArray()
        list.filter { !it.builtIn }.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("config", hudToJson(it.config))
            )
        }
        prefs.edit().putString(K_HUD_PRESETS, arr.toString()).apply()
    }

    // ---- profiles ----

    fun loadProfiles(): List<Profile> = decodeList(K_PROFILES) { o ->
        Profile(
            id = o.getString("id"),
            name = o.getString("name"),
            crosshair = crosshairFrom(o.getJSONObject("crosshair")),
            sensitivity = sensFrom(o.getJSONObject("sensitivity")),
            hud = hudFrom(o.getJSONObject("hud")),
            createdAt = o.optLong("createdAt", 0L)
        )
    }

    fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("crosshair", crosshairToJson(it.crosshair))
                    .put("sensitivity", sensToJson(it.sensitivity))
                    .put("hud", hudToJson(it.hud))
                    .put("createdAt", it.createdAt)
            )
        }
        prefs.edit().putString(K_PROFILES, arr.toString()).apply()
    }

    fun loadActiveProfileId(): String? = prefs.getString(K_ACTIVE, null)

    fun saveActiveProfileId(id: String?) {
        prefs.edit().apply {
            if (id == null) remove(K_ACTIVE) else putString(K_ACTIVE, id)
        }.apply()
    }

    // ---- sessions ----

    fun loadSessions(): List<SessionRecord> = decodeList(K_SESSIONS) { o ->
        SessionRecord(
            id = o.getString("id"),
            mode = runCatching { TrainingMode.valueOf(o.getString("mode")) }
                .getOrDefault(TrainingMode.AIM),
            difficulty = o.optString("difficulty", "Normal"),
            timestamp = o.optLong("timestamp", 0L),
            score = o.optInt("score", 0),
            hits = o.optInt("hits", 0),
            headshots = o.optInt("headshots", 0),
            misses = o.optInt("misses", 0),
            avgReactionMs = o.optInt("avgReactionMs", 0),
            bestReactionMs = o.optInt("bestReactionMs", 0),
            durationSec = o.optInt("durationSec", 0)
        )
    }

    fun saveSessions(list: List<SessionRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("mode", it.mode.name)
                    .put("difficulty", it.difficulty)
                    .put("timestamp", it.timestamp)
                    .put("score", it.score)
                    .put("hits", it.hits)
                    .put("headshots", it.headshots)
                    .put("misses", it.misses)
                    .put("avgReactionMs", it.avgReactionMs)
                    .put("bestReactionMs", it.bestReactionMs)
                    .put("durationSec", it.durationSec)
            )
        }
        prefs.edit().putString(K_SESSIONS, arr.toString()).apply()
    }

    // ---- settings ----

    fun loadSettings(): AppSettings = AppSettings(
        haptics = prefs.getBoolean(K_HAPTICS, true),
        durationSec = prefs.getInt(K_DURATION, 30)
    )

    fun saveSettings(s: AppSettings) {
        prefs.edit()
            .putBoolean(K_HAPTICS, s.haptics)
            .putInt(K_DURATION, s.durationSec)
            .apply()
    }

    // ---- helpers ----

    private fun putJson(key: String, o: JSONObject) {
        prefs.edit().putString(key, o.toString()).apply()
    }

    private fun <T> decode(key: String, f: (JSONObject) -> T): T? =
        prefs.getString(key, null)?.let { s -> runCatching { f(JSONObject(s)) }.getOrNull() }

    private fun <T> decodeList(key: String, f: (JSONObject) -> T): List<T> {
        val s = prefs.getString(key, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(s)
            (0 until arr.length()).map { f(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    private companion object {
        const val K_CROSSHAIR = "crosshair"
        const val K_SENS = "sensitivity"
        const val K_HUD = "hud"
        const val K_SENS_PRESETS = "sens_presets"
        const val K_HUD_PRESETS = "hud_presets"
        const val K_PROFILES = "profiles"
        const val K_ACTIVE = "active_profile"
        const val K_SESSIONS = "sessions"
        const val K_HAPTICS = "haptics"
        const val K_DURATION = "duration_sec"
    }
}

// ---- JSON codecs ----

private fun crosshairToJson(c: CrosshairConfig): JSONObject = JSONObject()
    .put("style", c.style.name)
    .put("color", c.color)
    .put("size", c.size.toDouble())
    .put("thickness", c.thickness.toDouble())
    .put("gap", c.gap.toDouble())
    .put("opacity", c.opacity.toDouble())
    .put("outline", c.outline)

private fun crosshairFrom(o: JSONObject): CrosshairConfig {
    val d = CrosshairConfig()
    return CrosshairConfig(
        style = runCatching { CrosshairStyle.valueOf(o.optString("style")) }.getOrDefault(d.style),
        color = o.optInt("color", d.color),
        size = o.optDouble("size", d.size.toDouble()).toFloat(),
        thickness = o.optDouble("thickness", d.thickness.toDouble()).toFloat(),
        gap = o.optDouble("gap", d.gap.toDouble()).toFloat(),
        opacity = o.optDouble("opacity", d.opacity.toDouble()).toFloat(),
        outline = o.optBoolean("outline", d.outline)
    )
}

private fun sensToJson(s: SensitivityConfig): JSONObject = JSONObject()
    .put("general", s.general)
    .put("redDot", s.redDot)
    .put("scope2x", s.scope2x)
    .put("scope4x", s.scope4x)
    .put("sniper", s.sniper)
    .put("freeLook", s.freeLook)

private fun sensFrom(o: JSONObject): SensitivityConfig {
    val d = SensitivityConfig()
    return SensitivityConfig(
        general = o.optInt("general", d.general),
        redDot = o.optInt("redDot", d.redDot),
        scope2x = o.optInt("scope2x", d.scope2x),
        scope4x = o.optInt("scope4x", d.scope4x),
        sniper = o.optInt("sniper", d.sniper),
        freeLook = o.optInt("freeLook", d.freeLook)
    )
}

private fun hudToJson(h: HudConfig): JSONObject = JSONObject()
    .put("fingers", h.fingers)
    .put("fireSize", h.fireSize)
    .put("fireOpacity", h.fireOpacity)
    .put("joystickSize", h.joystickSize)
    .put("hudScale", h.hudScale)

private fun hudFrom(o: JSONObject): HudConfig {
    val d = HudConfig()
    return HudConfig(
        fingers = o.optInt("fingers", d.fingers),
        fireSize = o.optInt("fireSize", d.fireSize),
        fireOpacity = o.optInt("fireOpacity", d.fireOpacity),
        joystickSize = o.optInt("joystickSize", d.joystickSize),
        hudScale = o.optInt("hudScale", d.hudScale)
    )
}
