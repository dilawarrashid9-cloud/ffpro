package com.ffpro.panel.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.RowScope
import com.ffpro.panel.data.CrosshairConfig
import com.ffpro.panel.ui.theme.FF

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    glow: Boolean = false,
    contentPadding: Dp = 16.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val base = modifier
        .clip(shape)
        .background(FF.SurfaceVar)
        .border(1.dp, if (glow) FF.Neon else FF.Neon.copy(alpha = 0.25f), shape)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m.padding(contentPadding), content = content)
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true
) {
    val shape = RoundedCornerShape(12.dp)
    if (filled) {
        Button(
            onClick = onClick,
            modifier = modifier.height(48.dp),
            enabled = enabled,
            shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = FF.Neon,
                contentColor = FF.Black,
                disabledContainerColor = FF.NeonDim.copy(alpha = 0.3f),
                disabledContentColor = FF.Muted
            )
        ) {
            Text(text.uppercase(), style = MaterialTheme.typography.labelLarge)
        }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier.height(48.dp),
            enabled = enabled,
            shape = shape,
            border = BorderStroke(1.dp, FF.Neon.copy(alpha = if (enabled) 0.8f else 0.3f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = FF.Neon)
        ) {
            Text(text.uppercase(), style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = FF.Neon,
        style = MaterialTheme.typography.titleMedium
    )
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = FF.Muted, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, color = FF.Neon, style = MaterialTheme.typography.titleMedium)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = FF.Neon,
                activeTrackColor = FF.Neon,
                inactiveTrackColor = FF.Neon.copy(alpha = 0.2f)
            )
        )
    }
}

@Composable
fun <T> OptionChips(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { opt ->
            FilterChip(
                selected = opt == selected,
                onClick = { onSelect(opt) },
                label = { Text(label(opt)) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = FF.SurfaceVar,
                    labelColor = FF.Text,
                    selectedContainerColor = FF.Neon,
                    selectedLabelColor = FF.Black
                )
            )
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = FF.Neon)
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Column {
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.headlineMedium,
                color = FF.Neon
            )
            if (subtitle != null) {
                Text(subtitle, color = FF.Muted, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    NeonCard(modifier, contentPadding = 12.dp) {
        Text(
            value,
            color = FF.Neon,
            fontSize = 18.sp,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1
        )
        Text(label.uppercase(), color = FF.Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
fun NameDialog(
    title: String,
    confirmLabel: String = "Save",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FF.SurfaceVar,
        title = { Text(title, color = FF.Neon) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { if (it.length <= 24) text = it },
                singleLine = true,
                label = { Text("Name") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FF.Neon,
                    focusedLabelColor = FF.Neon,
                    cursorColor = FF.Neon,
                    focusedTextColor = FF.Text,
                    unfocusedTextColor = FF.Text
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) {
                Text(confirmLabel.uppercase(), color = FF.Neon)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("CANCEL", color = FF.Muted) }
        }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = FF.SurfaceVar,
        title = { Text(title, color = FF.Neon) },
        text = { Text(message, color = FF.Text) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel.uppercase(), color = FF.Danger) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("CANCEL", color = FF.Muted) }
        }
    )
}

/** Small thumbnail of a crosshair on a dark tile. */
@Composable
fun CrosshairMini(cfg: CrosshairConfig, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .size(56.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0B120C))
            .border(1.dp, FF.Neon.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
    ) {
        drawCrosshair(cfg, Offset(size.width / 2, size.height / 2), scale = 0.35f)
    }
}
