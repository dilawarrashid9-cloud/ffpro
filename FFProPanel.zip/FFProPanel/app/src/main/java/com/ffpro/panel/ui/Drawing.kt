package com.ffpro.panel.ui

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.ffpro.panel.data.CrosshairConfig
import com.ffpro.panel.data.CrosshairStyle
import com.ffpro.panel.ui.theme.FF
import kotlin.math.max

// Human-silhouette target geometry, expressed as multiples of the head radius.
const val BODY_W = 2.6f
const val BODY_TOP = 1.05f
const val BODY_H = 3f
const val TARGET_BOTTOM = BODY_TOP + BODY_H

enum class Zone { HEAD, BODY, MISS }

fun hitZone(tap: Offset, head: Offset, r: Float): Zone {
    if ((tap - head).getDistance() <= r * 1.15f) return Zone.HEAD
    val bodyW = r * BODY_W
    val top = head.y + r * BODY_TOP
    val bottom = top + r * BODY_H
    if (tap.x in (head.x - bodyW / 2)..(head.x + bodyW / 2) && tap.y in top..bottom) {
        return Zone.BODY
    }
    return Zone.MISS
}

fun DrawScope.drawArena() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF040805), Color(0xFF0A140C))))
    val step = 48.dp.toPx()
    val line = FF.Neon.copy(alpha = 0.05f)
    var x = 0f
    while (x < size.width) {
        drawLine(line, Offset(x, 0f), Offset(x, size.height))
        x += step
    }
    var y = 0f
    while (y < size.height) {
        drawLine(line, Offset(0f, y), Offset(size.width, y))
        y += step
    }
}

fun DrawScope.drawHumanTarget(head: Offset, r: Float, alpha: Float = 1f) {
    val bodyW = r * BODY_W
    val bodyH = r * BODY_H
    val topLeft = Offset(head.x - bodyW / 2, head.y + r * BODY_TOP)
    val corner = CornerRadius(r * 0.6f)
    drawRoundRect(Color(0xFF14470C).copy(alpha = alpha), topLeft, Size(bodyW, bodyH), corner)
    drawRoundRect(
        FF.Neon.copy(alpha = 0.6f * alpha), topLeft, Size(bodyW, bodyH), corner,
        style = Stroke(2.dp.toPx())
    )
    drawCircle(FF.Neon.copy(alpha = alpha), r, head)
    drawCircle(Color.Black.copy(alpha = alpha), r * 0.28f, head)
}

/** Draws the configured crosshair centred on [c]. [scale] shrinks it for thumbnails. */
fun DrawScope.drawCrosshair(cfg: CrosshairConfig, c: Offset, scale: Float = 1f) {
    val a = cfg.opacity
    val color = Color(cfg.color).copy(alpha = a)
    val edge = Color.Black.copy(alpha = a)
    val len = cfg.size.dp.toPx() * scale
    val th = max(1f, cfg.thickness.dp.toPx() * scale)
    val gap = cfg.gap.dp.toPx() * scale
    val ol = max(1f, 1.5f.dp.toPx() * scale)

    val dirs: List<Pair<Float, Float>> = when (cfg.style) {
        CrosshairStyle.CROSS, CrosshairStyle.CROSS_DOT ->
            listOf(0f to -1f, 0f to 1f, -1f to 0f, 1f to 0f)
        CrosshairStyle.T_SHAPE -> listOf(0f to 1f, -1f to 0f, 1f to 0f)
        else -> emptyList()
    }

    fun start(d: Pair<Float, Float>) = Offset(c.x + d.first * gap, c.y + d.second * gap)
    fun end(d: Pair<Float, Float>) =
        Offset(c.x + d.first * (gap + len), c.y + d.second * (gap + len))

    if (cfg.outline) {
        dirs.forEach { d ->
            drawLine(edge, start(d), end(d), strokeWidth = th + ol * 2, cap = StrokeCap.Square)
        }
    }
    dirs.forEach { d ->
        drawLine(color, start(d), end(d), strokeWidth = th, cap = StrokeCap.Butt)
    }

    fun dot(r: Float) {
        if (cfg.outline) drawCircle(edge, r + ol, c)
        drawCircle(color, r, c)
    }

    when (cfg.style) {
        CrosshairStyle.CROSS_DOT -> dot(max(th * 0.9f, 1.5f))
        CrosshairStyle.DOT -> dot(max(th * 1.4f, 2f))
        CrosshairStyle.CIRCLE -> {
            val radius = gap + len / 2f
            if (cfg.outline) {
                drawCircle(edge, radius, c, style = Stroke(th + ol * 2))
            }
            drawCircle(color, radius, c, style = Stroke(th))
            dot(max(th * 0.7f, 1.5f))
        }
        else -> Unit
    }
}
