package com.ffpro.panel.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.Difficulty
import com.ffpro.panel.data.SessionRecord
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.newId
import com.ffpro.panel.ui.BODY_W
import com.ffpro.panel.ui.TARGET_BOTTOM
import com.ffpro.panel.ui.Zone
import com.ffpro.panel.ui.drawArena
import com.ffpro.panel.ui.drawCrosshair
import com.ffpro.panel.ui.drawHumanTarget
import com.ffpro.panel.ui.hitZone
import com.ffpro.panel.ui.theme.FF
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Headshot trainer: tap the head of each silhouette before it disappears. */
@Composable
fun AimTrainerScreen(vm: AppViewModel, onBack: () -> Unit) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current

    var difficulty by remember { mutableStateOf(Difficulty.NORMAL) }
    var phase by remember { mutableStateOf(Phase.READY) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var timeLeftMs by remember { mutableLongStateOf(0L) }
    var score by remember { mutableIntStateOf(0) }
    var heads by remember { mutableIntStateOf(0) }
    var bodies by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }
    var reactionSum by remember { mutableLongStateOf(0L) }
    var bestReaction by remember { mutableLongStateOf(Long.MAX_VALUE) }
    var head by remember { mutableStateOf(Offset.Zero) }
    var radius by remember { mutableFloatStateOf(0f) }
    var spawnAt by remember { mutableLongStateOf(0L) }
    var lastTap by remember { mutableStateOf<Offset?>(null) }
    var lastTapAt by remember { mutableLongStateOf(0L) }
    var feedback by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<SessionRecord?>(null) }
    var isBest by remember { mutableStateOf(false) }

    fun spawn(now: Long) {
        val r = with(density) { 22.dp.toPx() } * difficulty.sizeMul
        val bodyHalf = r * BODY_W / 2f
        val minX = bodyHalf + 8f
        val maxX = max(minX + 1f, area.width - bodyHalf - 8f)
        val minY = r + 8f
        val maxY = max(minY + 1f, area.height - r * TARGET_BOTTOM - 8f)
        head = Offset(
            Random.nextFloat() * (maxX - minX) + minX,
            Random.nextFloat() * (maxY - minY) + minY
        )
        radius = r
        spawnAt = now
    }

    fun start() {
        score = 0
        heads = 0
        bodies = 0
        misses = 0
        reactionSum = 0L
        bestReaction = Long.MAX_VALUE
        feedback = ""
        lastTap = null
        result = null
        timeLeftMs = vm.settings.durationSec * 1000L
        phase = Phase.RUNNING
    }

    fun handleTap(pos: Offset) {
        if (phase != Phase.RUNNING) return
        val now = SystemClock.elapsedRealtime()
        lastTap = pos
        lastTapAt = now
        when (hitZone(pos, head, radius)) {
            Zone.HEAD, Zone.BODY -> {
                val isHead = hitZone(pos, head, radius) == Zone.HEAD
                if (isHead) {
                    heads++
                    score += 100
                    feedback = "HEADSHOT +100"
                } else {
                    bodies++
                    score += 30
                    feedback = "BODY +30"
                }
                val rt = now - spawnAt
                reactionSum += rt
                bestReaction = min(bestReaction, rt)
                if (vm.settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                spawn(now)
            }
            Zone.MISS -> {
                misses++
                score = max(0, score - 10)
                feedback = "MISS -10"
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase != Phase.RUNNING) return@LaunchedEffect
        val start = SystemClock.elapsedRealtime()
        val total = vm.settings.durationSec * 1000L
        spawn(start)
        while (true) {
            withFrameNanos { }
            val now = SystemClock.elapsedRealtime()
            val left = total - (now - start)
            if (left <= 0L) {
                timeLeftMs = 0L
                val n = heads + bodies
                val rec = SessionRecord(
                    id = newId(),
                    mode = TrainingMode.AIM,
                    difficulty = difficulty.label,
                    timestamp = System.currentTimeMillis(),
                    score = score,
                    hits = n,
                    headshots = heads,
                    misses = misses,
                    avgReactionMs = if (n > 0) (reactionSum / n).toInt() else 0,
                    bestReactionMs = if (bestReaction == Long.MAX_VALUE) 0 else bestReaction.toInt(),
                    durationSec = vm.settings.durationSec
                )
                isBest = score > 0 && score > vm.bestScore(TrainingMode.AIM)
                vm.recordSession(rec)
                result = rec
                phase = Phase.DONE
                break
            }
            timeLeftMs = left
            if (now - spawnAt > difficulty.lifetimeMs) {
                misses++
                feedback = "TOO SLOW"
                spawn(now)
            }
        }
    }

    Column(Modifier.fillMaxSize().background(FF.Black)) {
        TrainerTopBar(
            title = "Headshot Aim",
            onBack = onBack,
            stats = listOf(
                "Time" to formatTime(timeLeftMs),
                "Score" to score.toString(),
                "HS" to heads.toString()
            )
        )
        Box(Modifier.weight(1f).fillMaxSize()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { area = it }
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = { handleTap(it) })
                    }
            ) {
                drawArena()
                if (phase == Phase.RUNNING && timeLeftMs >= 0L) {
                    val age = SystemClock.elapsedRealtime() - spawnAt
                    val frac = (1f - age.toFloat() / difficulty.lifetimeMs).coerceIn(0f, 1f)
                    drawHumanTarget(head, radius)
                    val ringR = radius * 1.45f
                    drawArc(
                        color = if (frac > 0.3f) FF.Neon else FF.Danger,
                        startAngle = -90f,
                        sweepAngle = 360f * frac,
                        useCenter = false,
                        topLeft = Offset(head.x - ringR, head.y - ringR),
                        size = Size(ringR * 2, ringR * 2),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                    )
                    val tap = lastTap
                    if (tap != null && SystemClock.elapsedRealtime() - lastTapAt < 250L) {
                        drawCrosshair(vm.crosshair, tap)
                    }
                }
            }
            if (phase == Phase.RUNNING && feedback.isNotEmpty()) {
                Text(
                    feedback,
                    color = if (feedback.startsWith("HEAD")) FF.Neon else FF.Amber,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                )
            }
            if (phase == Phase.READY) {
                ReadyOverlay(
                    title = "Headshot Aim",
                    description = "Tap the head of each target before its timer ring runs out. " +
                        "Head = 100, body = 30, miss = -10.",
                    difficulty = difficulty,
                    onDifficulty = { difficulty = it },
                    durationText = "${vm.settings.durationSec} second round",
                    onStart = { start() }
                )
            }
            val rec = result
            if (phase == Phase.DONE && rec != null) {
                ResultOverlay(rec, isBest, onAgain = { phase = Phase.READY }, onBack = onBack)
            }
        }
    }
}
