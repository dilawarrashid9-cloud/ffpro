package com.ffpro.panel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.CrosshairConfig
import com.ffpro.panel.data.CrosshairStyle
import com.ffpro.panel.ui.LabeledSlider
import com.ffpro.panel.ui.NeonButton
import com.ffpro.panel.ui.NeonCard
import com.ffpro.panel.ui.OptionChips
import com.ffpro.panel.ui.ScreenHeader
import com.ffpro.panel.ui.SectionTitle
import com.ffpro.panel.ui.drawCrosshair
import com.ffpro.panel.ui.drawHumanTarget
import com.ffpro.panel.ui.theme.FF
import kotlin.math.roundToInt

private val SWATCHES = listOf(
    0xFF39FF14, 0xFFFFFFFF, 0xFFFF3B3B, 0xFF00E5FF, 0xFFFFEB3B, 0xFFFF40FF, 0xFFFF9800
).map { it.toInt() }

private enum class PreviewBg(val label: String, val top: Color, val bottom: Color) {
    DARK("Dark", Color(0xFF050A06), Color(0xFF0E1A10)),
    GRASS("Grass", Color(0xFF3E7A2A), Color(0xFF2E5A1F)),
    SAND("Sand", Color(0xFFD6BC82), Color(0xFFC2A66B)),
    SKY("Sky", Color(0xFF9CCBF0), Color(0xFF7FB5E6)),
    WHITE("White", Color(0xFFFFFFFF), Color(0xFFE6E6E6))
}

private val QUICK_PRESETS = listOf(
    "Classic" to CrosshairConfig(),
    "Tiny dot" to CrosshairConfig(style = CrosshairStyle.DOT, size = 8f, thickness = 2f, gap = 0f),
    "Sniper ring" to CrosshairConfig(style = CrosshairStyle.CIRCLE, size = 20f, thickness = 1.5f, gap = 8f),
    "Tactical T" to CrosshairConfig(style = CrosshairStyle.T_SHAPE, size = 16f, thickness = 2f, gap = 4f),
    "Open cross" to CrosshairConfig(style = CrosshairStyle.CROSS, size = 22f, thickness = 2f, gap = 10f)
)

@Composable
fun CrosshairScreen(vm: AppViewModel) {
    val cfg = vm.crosshair
    var bg by remember { mutableStateOf(PreviewBg.DARK) }
    var showTarget by remember { mutableStateOf(true) }
    var hue by remember { mutableStateOf(120f) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        ScreenHeader("Crosshair", "Design and preview your reticle")

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, FF.Neon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                drawRect(Brush.verticalGradient(listOf(bg.top, bg.bottom)))
                val c = Offset(size.width / 2, size.height / 2)
                if (showTarget) {
                    val r = 14.dp.toPx()
                    drawHumanTarget(Offset(size.width * 0.72f, size.height * 0.28f), r, alpha = 0.9f)
                    drawHumanTarget(Offset(size.width * 0.2f, size.height * 0.4f), r * 0.7f, alpha = 0.9f)
                }
                drawCrosshair(cfg, c)
            }

            OptionChips(
                options = PreviewBg.values().toList(),
                selected = bg,
                label = { it.label },
                onSelect = { bg = it }
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show sample targets", color = FF.Text, modifier = Modifier.weight(1f))
                Switch(
                    checked = showTarget,
                    onCheckedChange = { showTarget = it },
                    colors = switchColors()
                )
            }

            SectionTitle("Quick styles")
            Row(Modifier.fillMaxWidth()) {
                OptionChips(
                    options = QUICK_PRESETS,
                    selected = QUICK_PRESETS.firstOrNull { it.second == cfg } ?: ("" to cfg),
                    label = { it.first },
                    onSelect = { vm.updateCrosshair(it.second) }
                )
            }

            NeonCard {
                SectionTitle("Shape")
                OptionChips(
                    options = CrosshairStyle.values().toList(),
                    selected = cfg.style,
                    label = { it.label },
                    onSelect = { vm.updateCrosshair(cfg.copy(style = it)) },
                    modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
                )
                LabeledSlider(
                    "Arm length", cfg.size, 4f..50f, "${cfg.size.roundToInt()} dp",
                    { vm.updateCrosshair(cfg.copy(size = it)) }
                )
                LabeledSlider(
                    "Thickness", cfg.thickness, 1f..8f, "%.1f dp".format(cfg.thickness),
                    { vm.updateCrosshair(cfg.copy(thickness = it)) }
                )
                LabeledSlider(
                    "Centre gap", cfg.gap, 0f..24f, "${cfg.gap.roundToInt()} dp",
                    { vm.updateCrosshair(cfg.copy(gap = it)) }
                )
                LabeledSlider(
                    "Opacity", cfg.opacity, 0.2f..1f, "${(cfg.opacity * 100).roundToInt()}%",
                    { vm.updateCrosshair(cfg.copy(opacity = it)) }
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark outline", color = FF.Text, modifier = Modifier.weight(1f))
                    Switch(
                        checked = cfg.outline,
                        onCheckedChange = { vm.updateCrosshair(cfg.copy(outline = it)) },
                        colors = switchColors()
                    )
                }
            }

            NeonCard {
                SectionTitle("Colour")
                Row(
                    Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SWATCHES.forEach { argb ->
                        val selected = argb == cfg.color
                        androidx.compose.foundation.layout.Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .border(
                                    if (selected) 3.dp else 1.dp,
                                    if (selected) Color.White else FF.Neon.copy(alpha = 0.3f),
                                    CircleShape
                                )
                                .clickable { vm.updateCrosshair(cfg.copy(color = argb)) }
                        )
                    }
                }
                LabeledSlider(
                    "Custom hue", hue, 0f..360f, "${hue.roundToInt()}°",
                    {
                        hue = it
                        vm.updateCrosshair(cfg.copy(color = Color.hsv(it, 1f, 1f).toArgb()))
                    }
                )
            }

            NeonButton(
                "Reset to default",
                { vm.updateCrosshair(CrosshairConfig()) },
                Modifier.fillMaxWidth(),
                filled = false
            )
        }
    }
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = FF.Black,
    checkedTrackColor = FF.Neon,
    uncheckedThumbColor = FF.Muted,
    uncheckedTrackColor = FF.SurfaceVar
)
