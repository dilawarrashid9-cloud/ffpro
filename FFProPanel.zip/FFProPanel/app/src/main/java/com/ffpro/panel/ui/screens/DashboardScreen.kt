package com.ffpro.panel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.streakDays
import com.ffpro.panel.data.summarize
import com.ffpro.panel.ui.CrosshairMini
import com.ffpro.panel.ui.NeonCard
import com.ffpro.panel.ui.OptionChips
import com.ffpro.panel.ui.SectionTitle
import com.ffpro.panel.ui.StatTile
import com.ffpro.panel.ui.theme.FF
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(vm: AppViewModel, go: (String) -> Unit) {
    val summary = remember(vm.sessions) { summarize(vm.sessions) }
    val streak = remember(vm.sessions) { streakDays(vm.sessions) }
    val active = vm.profiles.firstOrNull { it.id == vm.activeProfileId }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                "FF PRO PANEL",
                color = FF.Neon,
                style = MaterialTheme.typography.headlineLarge.copy(
                    shadow = Shadow(FF.Neon.copy(alpha = 0.8f), Offset.Zero, 24f)
                )
            )
            Text("Aim & reflex training hub", color = FF.Muted)
        }

        NeonCard(glow = true, onClick = { go("profiles") }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CrosshairMini(vm.crosshair)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("ACTIVE PROFILE", color = FF.Muted, fontSize = 10.sp)
                    Text(
                        active?.name ?: "No profile saved",
                        color = FF.Neon,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        "Sens ${vm.sensitivity.general}/${vm.sensitivity.redDot}/${vm.sensitivity.scope2x}" +
                            " • ${vm.hud.fingers}-finger HUD",
                        color = FF.Text
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("Sessions", summary.sessions.toString(), Modifier.weight(1f))
            StatTile("Best", summary.bestScore.toString(), Modifier.weight(1f))
            StatTile("Accuracy", "${(summary.avgAccuracy * 100).roundToInt()}%", Modifier.weight(1f))
            StatTile("Streak", "${streak}d", Modifier.weight(1f))
        }

        SectionTitle("Training")
        ModeCard(
            TrainingMode.AIM,
            "Tap the head before the ring runs out.",
            vm.bestScore(TrainingMode.AIM)
        ) { go("aim") }
        ModeCard(
            TrainingMode.REFLEX,
            "5 rounds. React the instant it turns green.",
            vm.bestScore(TrainingMode.REFLEX)
        ) { go("reflex") }
        ModeCard(
            TrainingMode.MOVING,
            "Track strafing targets that speed up.",
            vm.bestScore(TrainingMode.MOVING)
        ) { go("moving") }

        SectionTitle("Settings")
        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Haptic feedback", color = FF.Text, modifier = Modifier.weight(1f))
                Switch(
                    checked = vm.settings.haptics,
                    onCheckedChange = { vm.updateSettings(vm.settings.copy(haptics = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = FF.Black,
                        checkedTrackColor = FF.Neon,
                        uncheckedThumbColor = FF.Muted,
                        uncheckedTrackColor = FF.SurfaceVar
                    )
                )
            }
            Text("Round length", color = FF.Text, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            OptionChips(
                options = listOf(15, 30, 60),
                selected = vm.settings.durationSec,
                label = { "$it s" },
                onSelect = { vm.updateSettings(vm.settings.copy(durationSec = it)) }
            )
        }

        Text(
            "FF Pro Panel is a standalone training tool. It is not affiliated with Garena or " +
                "Free Fire, and it never connects to, modifies, or automates any game.",
            color = FF.Muted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun ModeCard(mode: TrainingMode, description: String, best: Int, onClick: () -> Unit) {
    NeonCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ModeIcon(mode)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(mode.label.uppercase(), color = FF.Text, style = MaterialTheme.typography.titleMedium)
                Text(description, color = FF.Muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("BEST", color = FF.Muted, fontSize = 10.sp)
                Text(best.toString(), color = FF.Neon, style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
private fun ModeIcon(mode: TrainingMode) {
    Canvas(Modifier.size(44.dp)) {
        val c = Offset(size.width / 2, size.height / 2)
        val sw = 2.5.dp.toPx()
        when (mode) {
            TrainingMode.AIM -> {
                drawCircle(FF.Neon, size.width * 0.45f, c, style = Stroke(sw))
                drawCircle(FF.Neon, size.width * 0.25f, c, style = Stroke(sw))
                drawCircle(FF.Neon, size.width * 0.08f, c)
            }
            TrainingMode.REFLEX -> {
                val p = Path().apply {
                    moveTo(size.width * 0.58f, size.height * 0.05f)
                    lineTo(size.width * 0.22f, size.height * 0.55f)
                    lineTo(size.width * 0.48f, size.height * 0.55f)
                    lineTo(size.width * 0.4f, size.height * 0.95f)
                    lineTo(size.width * 0.78f, size.height * 0.4f)
                    lineTo(size.width * 0.52f, size.height * 0.4f)
                    close()
                }
                drawPath(p, FF.Neon)
            }
            TrainingMode.MOVING -> {
                drawCircle(FF.Neon, size.width * 0.18f, c)
                val y = c.y
                drawLine(FF.Neon, Offset(size.width * 0.02f, y), Offset(size.width * 0.25f, y), sw, StrokeCap.Round)
                drawLine(FF.Neon, Offset(size.width * 0.75f, y), Offset(size.width * 0.98f, y), sw, StrokeCap.Round)
                drawLine(FF.Neon, Offset(size.width * 0.02f, y), Offset(size.width * 0.12f, y - 8.dp.toPx()), sw, StrokeCap.Round)
                drawLine(FF.Neon, Offset(size.width * 0.02f, y), Offset(size.width * 0.12f, y + 8.dp.toPx()), sw, StrokeCap.Round)
                drawLine(FF.Neon, Offset(size.width * 0.98f, y), Offset(size.width * 0.88f, y - 8.dp.toPx()), sw, StrokeCap.Round)
                drawLine(FF.Neon, Offset(size.width * 0.98f, y), Offset(size.width * 0.88f, y + 8.dp.toPx()), sw, StrokeCap.Round)
            }
        }
    }
}
