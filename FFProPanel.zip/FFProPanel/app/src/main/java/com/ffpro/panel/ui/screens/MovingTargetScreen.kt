package com.ffpro.panel.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.Difficulty
import com.ffpro.panel.data.SessionRecord
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.newId
import com.ffpro.panel.ui.BODY_W
import com.ffpro.panel.ui.TARGET_BOTTOM
import com.ffpro.panel.ui.Zone
import com.ffpro.panel.ui.drawArena
import com.ffpro.panel.ui.drawCrosshair
import com.ffpro.panel.ui.drawHumanTarget
import com.ffpro.panel.ui.hitZone
import com.ffpro.panel.ui.theme.FF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private data class Mover(
    val head: Offset,
    val vx: Float,
    val vy: Float,
    val turnAt: Long,
    val r: Float,
    val bornAt: Long
)

/** Moving target practice: strafing silhouettes that change direction at random. */
@Composable
fun MovingTargetScreen(vm: AppViewModel, onBack: () -> Unit) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current

    var difficulty by remember { mutableStateOf(Difficulty.NORMAL) }
    var phase by remember { mutableStateOf(Phase.READY) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var timeLeftMs by remember { mutableLongStateOf(0L) }
    var score by remember { mutableIntStateOf(0) }
    var heads by remember { mutableIntStateOf(0) }
    var bodies by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }
    var reactionSum by remember { mutableLongStateOf(0L) }
    var bestReaction by remember { mutableLongStateOf(Long.MAX_VALUE) }
    var targets by remember { mutableStateOf(listOf<Mover>()) }
    var lastTap by remember { mutableStateOf<Offset?>(null) }
    var lastTapAt by remember { mutableLongStateOf(0L) }
    var feedback by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<SessionRecord?>(null) }
    var isBest by remember { mutableStateOf(false) }

    fun newMover(now: Long): Mover {
        val r = with(density) { 22.dp.toPx() } * difficulty.sizeMul
        val bodyHalf = r * BODY_W / 2f
        val minX = bodyHalf + 4f
        val maxX = max(minX + 1f, area.width - bodyHalf - 4f)
        val minY = r + 4f
        val maxY = max(minY + 1f, area.height - r * TARGET_BOTTOM - 4f)
        val speed = with(density) { 150.dp.toPx() } * difficulty.speedMul *
            (0.8f + Random.nextFloat() * 0.5f)
        val dir = if (Random.nextBoolean()) 1f else -1f
        val vy = with(density) { (Random.nextFloat() - 0.5f) * 60.dp.toPx() }
        return Mover(
            head = Offset(
                Random.nextFloat() * (maxX - minX) + minX,
                Random.nextFloat() * (maxY - minY) + minY
            ),
            vx = speed * dir,
            vy = vy,
            turnAt = now + Random.nextLong(350L, 1300L),
            r = r,
            bornAt = now
        )
    }

    fun advance(m: Mover, dt: Float, now: Long, ramp: Float): Mover {
        val bodyHalf = m.r * BODY_W / 2f
        val minX = bodyHalf
        val maxX = max(minX + 1f, area.width - bodyHalf)
        val minY = m.r
        val maxY = max(minY + 1f, area.height - m.r * TARGET_BOTTOM)
        var x = m.head.x + m.vx * ramp * dt
        var y = m.head.y + m.vy * dt
        var vx = m.vx
        var vy = m.vy
        var turnAt = m.turnAt
        if (x < minX) { x = minX; vx = abs(vx) } else if (x > maxX) { x = maxX; vx = -abs(vx) }
        if (y < minY) { y = minY; vy = abs(vy) } else if (y > maxY) { y = maxY; vy = -abs(vy) }
        if (now >= turnAt) {
            vx = -vx
            turnAt = now + Random.nextLong(350L, 1300L)
        }
        return m.copy(head = Offset(x, y), vx = vx, vy = vy, turnAt = turnAt)
    }

    fun start() {
        score = 0
        heads = 0
        bodies = 0
        misses = 0
        reactionSum = 0L
        bestReaction = Long.MAX_VALUE
        feedback = ""
        lastTap = null
        result = null
        timeLeftMs = vm.settings.durationSec * 1000L
        phase = Phase.RUNNING
    }

    fun handleTap(pos: Offset) {
        if (phase != Phase.RUNNING) return
        val now = SystemClock.elapsedRealtime()
        lastTap = pos
        lastTapAt = now
        var idx = targets.indexOfFirst { hitZone(pos, it.head, it.r) == Zone.HEAD }
        var head = true
        if (idx < 0) {
            idx = targets.indexOfFirst { hitZone(pos, it.head, it.r) == Zone.BODY }
            head = false
        }
        if (idx >= 0) {
            val t = targets[idx]
            if (head) {
                heads++
                score += 100
                feedback = "HEADSHOT +100"
            } else {
                bodies++
                score += 30
                feedback = "BODY +30"
            }
            val rt = now - t.bornAt
            reactionSum += rt
            bestReaction = min(bestReaction, rt)
            if (vm.settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            targets = targets.toMutableList().also { it[idx] = newMover(now) }
        } else {
            misses++
            score = max(0, score - 10)
            feedback = "MISS -10"
        }
    }

    LaunchedEffect(phase) {
        if (phase != Phase.RUNNING) return@LaunchedEffect
        val start = SystemClock.elapsedRealtime()
        val total = vm.settings.durationSec * 1000L
        targets = List(difficulty.targetCount) { newMover(start) }
        var lastFrame = start
        while (true) {
            withFrameNanos { }
            val now = SystemClock.elapsedRealtime()
            val dt = ((now - lastFrame) / 1000f).coerceAtMost(0.05f)
            lastFrame = now
            val left = total - (now - start)
            if (left <= 0L) {
                timeLeftMs = 0L
                val n = heads + bodies
                val rec = SessionRecord(
                    id = newId(),
                    mode = TrainingMode.MOVING,
                    difficulty = difficulty.label,
                    timestamp = System.currentTimeMillis(),
                    score = score,
                    hits = n,
                    headshots = heads,
                    misses = misses,
                    avgReactionMs = if (n > 0) (reactionSum / n).toInt() else 0,
                    bestReactionMs = if (bestReaction == Long.MAX_VALUE) 0 else bestReaction.toInt(),
                    durationSec = vm.settings.durationSec
                )
                isBest = score > 0 && score > vm.bestScore(TrainingMode.MOVING)
                vm.recordSession(rec)
                result = rec
                phase = Phase.DONE
                break
            }
            timeLeftMs = left
            val ramp = 1f + 0.6f * (1f - left.toFloat() / total)
            targets = targets.map { advance(it, dt, now, ramp) }
        }
    }

    Column(Modifier.fillMaxSize().background(FF.Black)) {
        TrainerTopBar(
            title = "Moving Target",
            onBack = onBack,
            stats = listOf(
                "Time" to formatTime(timeLeftMs),
                "Score" to score.toString(),
                "HS" to heads.toString()
            )
        )
        Box(Modifier.weight(1f).fillMaxSize()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { area = it }
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = { handleTap(it) })
                    }
            ) {
                drawArena()
                if (phase == Phase.RUNNING) {
                    targets.forEach { drawHumanTarget(it.head, it.r) }
                    val tap = lastTap
                    if (tap != null && SystemClock.elapsedRealtime() - lastTapAt < 250L) {
                        drawCrosshair(vm.crosshair, tap)
                    }
                }
            }
            if (phase == Phase.RUNNING && feedback.isNotEmpty()) {
                Text(
                    feedback,
                    color = if (feedback.startsWith("HEAD")) FF.Neon else FF.Amber,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                )
            }
            if (phase == Phase.READY) {
                ReadyOverlay(
                    title = "Moving Target",
                    description = "Targets strafe and change direction, and speed up as the round goes on. " +
                        "Track them and tap the head.",
                    difficulty = difficulty,
                    onDifficulty = { difficulty = it },
                    durationText = "${vm.settings.durationSec} second round",
                    onStart = { start() }
                )
            }
            val rec = result
            if (phase == Phase.DONE && rec != null) {
                ResultOverlay(rec, isBest, onAgain = { phase = Phase.READY }, onBack = onBack)
            }
        }
    }
}
