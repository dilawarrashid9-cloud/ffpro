package com.ffpro.panel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.CrosshairConfig
import com.ffpro.panel.data.HudConfig
import com.ffpro.panel.data.SensitivityConfig
import com.ffpro.panel.ui.LabeledSlider
import com.ffpro.panel.ui.NameDialog
import com.ffpro.panel.ui.NeonButton
import com.ffpro.panel.ui.NeonCard
import com.ffpro.panel.ui.OptionChips
import com.ffpro.panel.ui.ScreenHeader
import com.ffpro.panel.ui.SectionTitle
import com.ffpro.panel.ui.drawCrosshair
import com.ffpro.panel.ui.theme.FF
import kotlin.math.min
import kotlin.math.roundToInt

private val TABS = listOf("Sensitivity", "HUD layout")

@Composable
fun PresetsScreen(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        ScreenHeader("Presets", "Personal sensitivity & HUD notes")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OptionChips(
                options = TABS,
                selected = TABS[tab],
                label = { it },
                onSelect = { tab = TABS.indexOf(it) }
            )
            if (tab == 0) SensitivityTab(vm) else HudTab(vm)
        }
    }
}

@Composable
private fun SensitivityTab(vm: AppViewModel) {
    val s = vm.sensitivity
    var showSave by remember { mutableStateOf(false) }

    Text(
        "Record the values you like. This panel only stores your numbers; it never changes any game.",
        color = FF.Muted
    )

    NeonCard {
        SectionTitle("Current sensitivity")
        SensSlider("General", s.general) { vm.updateSensitivity(s.copy(general = it)) }
        SensSlider("Red dot", s.redDot) { vm.updateSensitivity(s.copy(redDot = it)) }
        SensSlider("2x scope", s.scope2x) { vm.updateSensitivity(s.copy(scope2x = it)) }
        SensSlider("4x scope", s.scope4x) { vm.updateSensitivity(s.copy(scope4x = it)) }
        SensSlider("Sniper scope", s.sniper) { vm.updateSensitivity(s.copy(sniper = it)) }
        SensSlider("Free look", s.freeLook) { vm.updateSensitivity(s.copy(freeLook = it)) }
    }
    NeonButton("Save as preset", { showSave = true }, Modifier.fillMaxWidth())

    SectionTitle("Saved presets")
    vm.sensPresets.forEach { p ->
        PresetRow(
            name = p.name,
            summary = sensSummary(p.config),
            builtIn = p.builtIn,
            selected = p.config == s,
            onLoad = { vm.loadSensPreset(p) },
            onDelete = { vm.deleteSensPreset(p.id) }
        )
    }

    if (showSave) {
        NameDialog(
            title = "Save sensitivity preset",
            onConfirm = { vm.saveSensPreset(it); showSave = false },
            onDismiss = { showSave = false }
        )
    }
}

@Composable
private fun HudTab(vm: AppViewModel) {
    val h = vm.hud
    var showSave by remember { mutableStateOf(false) }

    HudPreview(h, vm.crosshair)

    NeonCard {
        SectionTitle("Layout")
        OptionChips(
            options = listOf(2, 3, 4),
            selected = h.fingers,
            label = { "$it fingers" },
            onSelect = { vm.updateHud(h.copy(fingers = it)) },
            modifier = Modifier.padding(vertical = 8.dp)
        )
        LabeledSlider(
            "Fire button size", h.fireSize.toFloat(), 30f..120f, "${h.fireSize}%",
            { vm.updateHud(h.copy(fireSize = it.roundToInt())) }
        )
        LabeledSlider(
            "Fire button opacity", h.fireOpacity.toFloat(), 20f..100f, "${h.fireOpacity}%",
            { vm.updateHud(h.copy(fireOpacity = it.roundToInt())) }
        )
        LabeledSlider(
            "Joystick size", h.joystickSize.toFloat(), 30f..100f, "${h.joystickSize}%",
            { vm.updateHud(h.copy(joystickSize = it.roundToInt())) }
        )
        LabeledSlider(
            "HUD scale", h.hudScale.toFloat(), 70f..130f, "${h.hudScale}%",
            { vm.updateHud(h.copy(hudScale = it.roundToInt())) }
        )
    }
    NeonButton("Save as preset", { showSave = true }, Modifier.fillMaxWidth())

    SectionTitle("Saved presets")
    vm.hudPresets.forEach { p ->
        PresetRow(
            name = p.name,
            summary = "${p.config.fingers} fingers • fire ${p.config.fireSize}% • HUD ${p.config.hudScale}%",
            builtIn = p.builtIn,
            selected = p.config == h,
            onLoad = { vm.loadHudPreset(p) },
            onDelete = { vm.deleteHudPreset(p.id) }
        )
    }

    if (showSave) {
        NameDialog(
            title = "Save HUD preset",
            onConfirm = { vm.saveHudPreset(it); showSave = false },
            onDismiss = { showSave = false }
        )
    }
}

@Composable
private fun SensSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    LabeledSlider(label, value.toFloat(), 0f..100f, value.toString(), { onChange(it.roundToInt()) })
}

private fun sensSummary(c: SensitivityConfig) =
    "Gen ${c.general} • RD ${c.redDot} • 2x ${c.scope2x} • 4x ${c.scope4x} • AWM ${c.sniper} • FL ${c.freeLook}"

@Composable
private fun PresetRow(
    name: String,
    summary: String,
    builtIn: Boolean,
    selected: Boolean,
    onLoad: () -> Unit,
    onDelete: () -> Unit
) {
    NeonCard(glow = selected) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    name + if (builtIn) "  •  built-in" else "",
                    color = if (selected) FF.Neon else FF.Text
                )
                Text(summary, color = FF.Muted)
            }
        }
        Row(
            Modifier.padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NeonButton(if (selected) "Loaded" else "Load", onLoad, Modifier.weight(1f), enabled = !selected)
            if (!builtIn) {
                NeonButton("Delete", onDelete, Modifier.weight(1f), filled = false)
            }
        }
    }
}

/** Mock landscape phone showing where HUD controls would sit. */
@Composable
fun HudPreview(h: HudConfig, crosshair: CrosshairConfig, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .fillMaxWidth()
            .aspectRatio(2.1f)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF07110A), Color(0xFF0D1F12))))
            .border(1.dp, FF.Neon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        val w = size.width
        val ht = size.height
        val s = h.hudScale / 100f
        val stroke = Stroke(2.dp.toPx())
        val btnAlpha = h.fireOpacity / 100f

        // mini-map
        drawRoundRect(
            FF.Neon.copy(alpha = 0.12f),
            Offset(w * 0.02f, ht * 0.06f),
            Size(w * 0.2f * s, ht * 0.3f * s),
            CornerRadius(8.dp.toPx())
        )
        drawRoundRect(
            FF.Neon.copy(alpha = 0.5f),
            Offset(w * 0.02f, ht * 0.06f),
            Size(w * 0.2f * s, ht * 0.3f * s),
            CornerRadius(8.dp.toPx()),
            style = stroke
        )

        // joystick
        val jr = ht * 0.17f * (h.joystickSize / 60f) * s
        val jc = Offset(w * 0.14f, ht * 0.72f)
        drawCircle(FF.Neon.copy(alpha = 0.12f), jr, jc)
        drawCircle(FF.Neon.copy(alpha = 0.6f), jr, jc, style = stroke)
        drawCircle(FF.Neon.copy(alpha = 0.5f), jr * 0.35f, jc)

        fun button(c: Offset, r: Float, alpha: Float) {
            drawCircle(FF.Neon.copy(alpha = 0.18f * alpha), r, c)
            drawCircle(FF.Neon.copy(alpha = 0.9f * alpha), r, c, style = stroke)
        }

        // main fire button
        val fr = ht * 0.13f * (h.fireSize / 70f) * s
        button(Offset(w * 0.86f, ht * 0.6f), min(fr, ht * 0.3f), btnAlpha)
        // jump + crouch
        button(Offset(w * 0.94f, ht * 0.84f), ht * 0.07f * s, 0.8f)
        button(Offset(w * 0.76f, ht * 0.84f), ht * 0.07f * s, 0.8f)
        // extra fire buttons for claw layouts
        if (h.fingers >= 3) button(Offset(w * 0.3f, ht * 0.58f), min(fr, ht * 0.3f) * 0.85f, btnAlpha)
        if (h.fingers >= 4) button(Offset(w * 0.9f, ht * 0.3f), ht * 0.08f * s, btnAlpha)

        drawCrosshair(crosshair, Offset(w / 2, ht * 0.45f), scale = 0.6f)
    }
}
