package com.ffpro.panel.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.Profile
import com.ffpro.panel.ui.ConfirmDialog
import com.ffpro.panel.ui.CrosshairMini
import com.ffpro.panel.ui.NameDialog
import com.ffpro.panel.ui.NeonButton
import com.ffpro.panel.ui.NeonCard
import com.ffpro.panel.ui.ScreenHeader
import com.ffpro.panel.ui.SectionTitle
import com.ffpro.panel.ui.theme.FF
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfilesScreen(vm: AppViewModel) {
    var showSave by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Profile?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        ScreenHeader("Profiles", "Bundle crosshair, sensitivity and HUD")

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            NeonCard {
                SectionTitle("Current setup")
                Row(
                    Modifier.padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CrosshairMini(vm.crosshair)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            "${vm.crosshair.style.label} crosshair",
                            color = FF.Text,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Sens ${vm.sensitivity.general}/${vm.sensitivity.redDot}/${vm.sensitivity.scope2x}" +
                                " • ${vm.hud.fingers}-finger HUD",
                            color = FF.Muted
                        )
                    }
                }
                NeonButton(
                    "Save as new profile",
                    { showSave = true },
                    Modifier.fillMaxWidth().padding(top = 12.dp)
                )
            }

            SectionTitle("Saved profiles")
            if (vm.profiles.isEmpty()) {
                Text("No profiles yet. Set up your crosshair, sensitivity and HUD, then save them here.", color = FF.Muted)
            }
            vm.profiles.forEach { p ->
                val active = p.id == vm.activeProfileId
                NeonCard(glow = active) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CrosshairMini(p.crosshair)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.name,
                                color = if (active) FF.Neon else FF.Text,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "Sens ${p.sensitivity.general}/${p.sensitivity.redDot}/${p.sensitivity.scope2x}" +
                                    " • ${p.hud.fingers}F HUD",
                                color = FF.Muted
                            )
                            Text(
                                SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(p.createdAt)),
                                color = FF.Muted
                            )
                        }
                        if (active) {
                            Text("ACTIVE", color = FF.Neon, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                    Row(
                        Modifier.padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NeonButton("Apply", { vm.applyProfile(p.id) }, Modifier.weight(1f), enabled = !active)
                        NeonButton("Update", { vm.updateProfileFromCurrent(p.id) }, Modifier.weight(1f), filled = false)
                        NeonButton("Delete", { toDelete = p }, Modifier.weight(1f), filled = false)
                    }
                }
            }
        }
    }

    if (showSave) {
        NameDialog(
            title = "Name this profile",
            onConfirm = { vm.saveProfile(it); showSave = false },
            onDismiss = { showSave = false }
        )
    }
    toDelete?.let { p ->
        ConfirmDialog(
            title = "Delete profile?",
            message = "\"${p.name}\" will be removed from this device.",
            confirmLabel = "Delete",
            onConfirm = { vm.deleteProfile(p.id); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
}
