package com.ffpro.panel.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Column as LayoutColumn
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.SessionRecord
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.newId
import com.ffpro.panel.ui.theme.FF
import kotlin.math.max
import kotlin.random.Random

private enum class RPhase { READY, WAITING, GO, EARLY, ROUND_RESULT, DONE }

private const val ROUNDS = 5

/** Reflex drill: wait for the screen to flash green, then tap as fast as you can. */
@Composable
fun ReflexDrillScreen(vm: AppViewModel, onBack: () -> Unit) {
    val haptic = LocalHapticFeedback.current

    var phase by remember { mutableStateOf(RPhase.READY) }
    var roundKey by remember { mutableIntStateOf(0) }
    var goAt by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var falseStarts by remember { mutableIntStateOf(0) }
    var lastMs by remember { mutableLongStateOf(0L) }
    val times = remember { mutableStateListOf<Long>() }
    var result by remember { mutableStateOf<SessionRecord?>(null) }
    var isBest by remember { mutableStateOf(false) }

    fun finish() {
        val avg = times.average().toInt()
        val best = times.minOrNull()?.toInt() ?: 0
        val score = max(0, (600 - avg) * 2 - falseStarts * 50)
        val rec = SessionRecord(
            id = newId(),
            mode = TrainingMode.REFLEX,
            difficulty = "Standard",
            timestamp = System.currentTimeMillis(),
            score = score,
            hits = times.size,
            headshots = 0,
            misses = falseStarts,
            avgReactionMs = avg,
            bestReactionMs = best,
            durationSec = ((SystemClock.elapsedRealtime() - startedAt) / 1000L).toInt()
        )
        isBest = score > 0 && score > vm.bestScore(TrainingMode.REFLEX)
        vm.recordSession(rec)
        result = rec
        phase = RPhase.DONE
    }

    fun begin() {
        times.clear()
        falseStarts = 0
        lastMs = 0L
        result = null
        startedAt = SystemClock.elapsedRealtime()
        roundKey++
        phase = RPhase.WAITING
    }

    fun onPress() {
        when (phase) {
            RPhase.WAITING -> {
                falseStarts++
                phase = RPhase.EARLY
            }
            RPhase.GO -> {
                val rt = SystemClock.elapsedRealtime() - goAt
                lastMs = rt
                times.add(rt)
                if (vm.settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                if (times.size >= ROUNDS) finish() else phase = RPhase.ROUND_RESULT
            }
            RPhase.EARLY, RPhase.ROUND_RESULT -> {
                roundKey++
                phase = RPhase.WAITING
            }
            else -> Unit
        }
    }

    LaunchedEffect(phase, roundKey) {
        if (phase == RPhase.WAITING) {
            kotlinx.coroutines.delay(Random.nextLong(1200L, 4000L))
            goAt = SystemClock.elapsedRealtime()
            phase = RPhase.GO
        }
    }

    val bg = when (phase) {
        RPhase.WAITING -> Color(0xFF3A0000)
        RPhase.GO -> FF.Neon
        RPhase.EARLY -> Color(0xFF4A2A00)
        else -> FF.Black
    }

    Column(Modifier.fillMaxSize().background(FF.Black)) {
        TrainerTopBar(
            title = "Reflex Drill",
            onBack = onBack,
            stats = listOf(
                "Round" to "${minOf(times.size + 1, ROUNDS)}/$ROUNDS",
                "False" to falseStarts.toString()
            )
        )
        Box(
            Modifier
                .weight(1f)
                .fillMaxSize()
                .background(bg)
                .pointerInput(Unit) { detectTapGestures(onPress = { onPress() }) },
            contentAlignment = Alignment.Center
        ) {
            when (phase) {
                RPhase.WAITING -> BigText("WAIT…", "Tap only when the screen turns green", Color.White)
                RPhase.GO -> BigText("TAP!", "", FF.Black)
                RPhase.EARLY -> BigText("TOO EARLY", "Tap to retry this round", FF.Amber)
                RPhase.ROUND_RESULT -> BigText(
                    "$lastMs ms",
                    "Round ${times.size} of $ROUNDS done — tap for the next",
                    FF.Neon
                )
                else -> Unit
            }
            if (phase == RPhase.READY) {
                ReadyOverlay(
                    title = "Reflex Drill",
                    description = "Wait for the screen to turn neon green, then tap as fast as you can. " +
                        "Tapping early counts as a false start.",
                    difficulty = null,
                    onDifficulty = {},
                    durationText = "$ROUNDS rounds",
                    onStart = { begin() }
                )
            }
            val rec = result
            if (phase == RPhase.DONE && rec != null) {
                ResultOverlay(rec, isBest, onAgain = { phase = RPhase.READY }, onBack = onBack)
            }
        }
    }
}

@Composable
private fun BigText(title: String, subtitle: String, color: Color) {
    LayoutColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(24.dp)
    ) {
        Text(
            title,
            color = color,
            fontSize = 48.sp,
            style = MaterialTheme.typography.headlineLarge,
            textAlign = TextAlign.Center
        )
        if (subtitle.isNotEmpty()) {
            Text(subtitle, color = color.copy(alpha = 0.85f), textAlign = TextAlign.Center)
        }
    }
}
