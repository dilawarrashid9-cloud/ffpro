package com.ffpro.panel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.ffpro.panel.AppViewModel
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.data.summarize
import com.ffpro.panel.ui.ConfirmDialog
import com.ffpro.panel.ui.NeonButton
import com.ffpro.panel.ui.NeonCard
import com.ffpro.panel.ui.OptionChips
import com.ffpro.panel.ui.ScreenHeader
import com.ffpro.panel.ui.SectionTitle
import com.ffpro.panel.ui.StatTile
import com.ffpro.panel.ui.theme.FF
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun StatsScreen(vm: AppViewModel) {
    var filter by remember { mutableStateOf<TrainingMode?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val all = vm.sessions
    val shown = remember(all, filter) { if (filter == null) all else all.filter { it.mode == filter } }
    val sum = remember(shown) { summarize(shown) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        ScreenHeader("Statistics", "Your training history")

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OptionChips(
                options = listOf<TrainingMode?>(null) + TrainingMode.values().toList(),
                selected = filter,
                label = { it?.label ?: "All modes" },
                onSelect = { filter = it }
            )

            if (shown.isEmpty()) {
                NeonCard {
                    Text("No sessions yet", color = FF.Neon, style = MaterialTheme.typography.titleMedium)
                    Text("Finish a training round and your results will show up here.", color = FF.Muted)
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("Sessions", sum.sessions.toString(), Modifier.weight(1f))
                    StatTile("Best score", sum.bestScore.toString(), Modifier.weight(1f))
                    StatTile("Accuracy", "${(sum.avgAccuracy * 100).roundToInt()}%", Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("Time trained", formatDuration(sum.totalSeconds), Modifier.weight(1f))
                    StatTile(
                        "Avg reaction",
                        if (sum.avgReactionMs > 0) "${sum.avgReactionMs} ms" else "—",
                        Modifier.weight(1f)
                    )
                    StatTile(
                        "Best reaction",
                        if (sum.bestReactionMs > 0) "${sum.bestReactionMs} ms" else "—",
                        Modifier.weight(1f)
                    )
                }

                NeonCard {
                    SectionTitle("Recent scores")
                    ScoreChart(
                        shown.takeLast(12).map { it.score },
                        Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .padding(top = 12.dp)
                    )
                    Text("Oldest → newest (latest highlighted)", color = FF.Muted, modifier = Modifier.padding(top = 6.dp))
                }

                if (filter == null) {
                    NeonCard {
                        SectionTitle("Personal bests")
                        TrainingMode.values().forEach { m ->
                            Row(
                                Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(m.label, color = FF.Text)
                                Text(vm.bestScore(m).toString(), color = FF.Neon)
                            }
                        }
                    }
                }

                SectionTitle("History")
                val fmt = remember { SimpleDateFormat("MMM d • HH:mm", Locale.getDefault()) }
                shown.takeLast(30).reversed().forEach { r ->
                    NeonCard(contentPadding = 12.dp) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(r.mode.label, color = FF.Text, style = MaterialTheme.typography.titleMedium)
                            Text(r.score.toString(), color = FF.Neon, style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "${fmt.format(Date(r.timestamp))} • ${r.difficulty} • " +
                                "${(r.accuracy * 100).roundToInt()}% acc" +
                                if (r.avgReactionMs > 0) " • ${r.avgReactionMs} ms" else "",
                            color = FF.Muted
                        )
                    }
                }

                NeonButton(
                    "Clear all history",
                    { confirmClear = true },
                    Modifier.fillMaxWidth(),
                    filled = false
                )
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Clear history?",
            message = "All saved training sessions will be deleted from this device.",
            confirmLabel = "Clear",
            onConfirm = { vm.clearSessions(); confirmClear = false },
            onDismiss = { confirmClear = false }
        )
    }
}

private fun formatDuration(totalSeconds: Int): String {
    val m = totalSeconds / 60
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m ${totalSeconds % 60}s"
}

@Composable
private fun ScoreChart(scores: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (scores.isEmpty()) return@Canvas
        val maxV = max(1, scores.maxOrNull() ?: 1).toFloat()
        val n = scores.size
        val gap = 6.dp.toPx()
        val barW = (size.width - gap * (n - 1)) / n
        scores.forEachIndexed { i, s ->
            val h = (s / maxV) * (size.height - 4.dp.toPx())
            drawRoundRect(
                color = if (i == n - 1) FF.Neon else FF.NeonDim,
                topLeft = Offset(i * (barW + gap), size.height - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(4.dp.toPx())
            )
        }
    }
}
