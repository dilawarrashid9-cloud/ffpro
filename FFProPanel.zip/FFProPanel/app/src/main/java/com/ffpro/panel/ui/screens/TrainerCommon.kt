package com.ffpro.panel.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffpro.panel.data.Difficulty
import com.ffpro.panel.data.SessionRecord
import com.ffpro.panel.data.TrainingMode
import com.ffpro.panel.ui.NeonButton
import com.ffpro.panel.ui.OptionChips
import com.ffpro.panel.ui.StatTile
import com.ffpro.panel.ui.theme.FF
import kotlin.math.roundToInt

enum class Phase { READY, RUNNING, DONE }

fun formatTime(ms: Long): String {
    val s = (ms + 999) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun TrainerTopBar(title: String, onBack: () -> Unit, stats: List<Pair<String, String>>) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(FF.Surface)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = FF.Neon)
        }
        Text(
            title.uppercase(),
            color = FF.Neon,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        stats.forEach { (label, value) ->
            Column(
                Modifier.padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(value, color = FF.Text, fontSize = 16.sp, style = MaterialTheme.typography.titleMedium)
                Text(label.uppercase(), color = FF.Muted, fontSize = 9.sp)
            }
        }
    }
}

/** Dimmed overlay that blocks taps from reaching the game surface behind it. */
@Composable
private fun OverlayBox(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.88f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun ReadyOverlay(
    title: String,
    description: String,
    difficulty: Difficulty?,
    onDifficulty: (Difficulty) -> Unit,
    durationText: String,
    onStart: () -> Unit
) {
    OverlayBox {
        Column(
            Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                title.uppercase(),
                color = FF.Neon,
                style = MaterialTheme.typography.headlineMedium.copy(
                    shadow = Shadow(FF.Neon.copy(alpha = 0.7f), Offset.Zero, 20f)
                ),
                textAlign = TextAlign.Center
            )
            Text(description, color = FF.Text, textAlign = TextAlign.Center)
            Text(durationText, color = FF.Muted)
            if (difficulty != null) {
                OptionChips(
                    options = Difficulty.values().toList(),
                    selected = difficulty,
                    label = { it.label },
                    onSelect = onDifficulty
                )
            }
            NeonButton("Start", onStart, Modifier.fillMaxWidth(0.7f))
        }
    }
}

@Composable
fun ResultOverlay(
    r: SessionRecord,
    isBest: Boolean,
    onAgain: () -> Unit,
    onBack: () -> Unit
) {
    OverlayBox {
        Column(
            Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                if (isBest) "NEW PERSONAL BEST" else "SESSION COMPLETE",
                color = if (isBest) FF.Amber else FF.Neon,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                r.score.toString(),
                color = FF.Neon,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 56.sp,
                    shadow = Shadow(FF.Neon.copy(alpha = 0.7f), Offset.Zero, 28f)
                )
            )
            Text(r.mode.label + " • " + r.difficulty, color = FF.Muted)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("Accuracy", "${(r.accuracy * 100).roundToInt()}%", Modifier.weight(1f))
                StatTile("Hits", r.hits.toString(), Modifier.weight(1f))
                if (r.mode != TrainingMode.REFLEX) {
                    StatTile("Headshots", r.headshots.toString(), Modifier.weight(1f))
                } else {
                    StatTile("False starts", r.misses.toString(), Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(
                    "Avg reaction",
                    if (r.avgReactionMs > 0) "${r.avgReactionMs} ms" else "—",
                    Modifier.weight(1f)
                )
                StatTile(
                    "Best reaction",
                    if (r.bestReactionMs > 0) "${r.bestReactionMs} ms" else "—",
                    Modifier.weight(1f)
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonButton("Again", onAgain, Modifier.weight(1f))
                NeonButton("Exit", onBack, Modifier.weight(1f), filled = false)
            }
        }
    }
}
