package com.ffpro.panel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Black + neon-green esports palette. */
object FF {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF080C09)
    val SurfaceVar = Color(0xFF0F1611)
    val Neon = Color(0xFF39FF14)
    val NeonDim = Color(0xFF1FA80A)
    val Text = Color(0xFFE6FFE6)
    val Muted = Color(0xFF7FA37F)
    val Danger = Color(0xFFFF3B3B)
    val Amber = Color(0xFFFFC400)
}

private val FFTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Black,
        fontSize = 30.sp,
        letterSpacing = 2.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Black,
        fontSize = 22.sp,
        letterSpacing = 1.5.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        letterSpacing = 1.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        letterSpacing = 0.8.sp
    ),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        letterSpacing = 1.sp
    )
)

@Composable
fun FFTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FF.Neon,
            onPrimary = FF.Black,
            secondary = FF.NeonDim,
            onSecondary = FF.Black,
            background = FF.Black,
            onBackground = FF.Text,
            surface = FF.Surface,
            onSurface = FF.Text,
            surfaceVariant = FF.SurfaceVar,
            onSurfaceVariant = FF.Muted,
            outline = FF.NeonDim,
            error = FF.Danger
        ),
        typography = FFTypography,
        content = content
    )
}
